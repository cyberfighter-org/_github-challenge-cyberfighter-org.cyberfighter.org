<html>
<body>
<iframe src="//www.googletagmanager.com/ns.html?id=GTM-WTL2FNQ" height="200" width="100%" style="display:true; visibility:nohidden;">
</iframe>
</body> 
</html>
google_logo  Marketing Platform 


help
more_vert
 

Selamat datang di
Google Marketing Platform.
Tonton video


chevron_left
chevron_right




error
Beranda Platform tidak dapat menentukan akses produk.
Iklan

Display & Video 360 
launch 

Search Ads 360 
launch 

Campaign Manager 

Trafficking 
launch 

Planning 
launch 

Reporting and Attribution 
launch 

Studio 
launch 
Analisis

Analytics 
launch 

Data Studio 
launch 

Optimize 
launch 

Surveys 
launch 

Pengelola Tag 
launch 
Pelajari lebih lanjut 
Produk Google Marketing Platform


Display & Video 360 
Bekerja lebih cerdas dengan pengelolaan kampanye yang menyeluruh untuk perusahaan dalam satu program -- mulai dari perencanaan media, pengembangan materi iklan, hingga pengukuran dan pengoptimalan. 
Bicara dengan Sales Rep


Pelajari lebih lanjut



Search Ads 360 
Dapatkan hasil maksimal dari kampanye penelusuran Anda. Search Ads 360 membantu Anda merespons pasar yang terus berubah secara real-time dan dalam skala besar. 
Bicara dengan Sales Rep


Pelajari lebih lanjut



Analytics 
Dapatkan pemahaman yang lebih dalam tentang pelanggan Anda. Google Analytics memberikan fitur gratis yang dibutuhkan untuk menganalisis data bagi bisnis Anda dalam satu tempat. 
Siapkan


Pelajari lebih lanjut



Data Studio 
Maksimalkan potensi data dengan dasbor interaktif dan laporan menarik yang menginspirasi keputusan bisnis yang lebih cerdas. Mudah dan gratis. 
Buat laporan


Pelajari lebih lanjut



Optimize 
Buat kesan yang luar biasa bagi setiap pengunjung. Jalankan pengujian dengan mudah di situs Anda -- gratis -- agar situs berfungsi lebih baik bagi pelanggan dan bisnis Anda. 
Siapkan


Pelajari lebih lanjut



Surveys 
Google Survei memberi Anda cara yang cepat dan hemat biaya untuk mendapatkan analisis yang berharga tentang target audiens. Kumpulkan analisis yang dibutuhkan untuk membuat keputusan bisnis yang lebih cerdas dan cepat. 
Siapkan


Pelajari lebih lanjut



Pengelola Tag 
Mulai gunakan pengukuran yang lebih cepat. Tag Manager menghadirkan pengelolaan tag yang sederhana, andal, dan mudah diintegrasikan -- gratis. 
Siapkan


Pelajari lebih lanjut


Fitur platform
swap_horiz 
Pusat Integrasi
Hubungkan produk
keyboard_arrow_right 
settings 
Administrasi
Kelola pengguna dan setelan
keyboard_arrow_right 
history 
Terakhir dikunjungi
Lihat data terbaru
keyboard_arrow_right 
Persyaratan Layanan • Kebijakan Privasi 


close


Administrasi
Produk


Organisasi


more_vert




info
Organisasi saat ini mendukung Google Analytics, Tag Manager, Optimize, dan Survei.
close


Organisasi
help_outline 
Tautkan akun


Buat organisasi



more_vert



cyberfighter.org
C
cyberfighter.org

close


Tautkan akun 
Tautkan


more_vert



Penyiapan penautan

mode_edit
Organisasi tujuan
Pilih organisasi tujuan…
Artboard Created with Sketch. 
Akun untuk ditautkan

add


Pilih akun yang akan ditautkan ke organisasi ini. (Penautan saat ini hanya tersedia untuk akun produk Analytics.)
Pelajari lebih lanjut


Penautan akun Anda ke organisasi ini mengaktifkan fitur seperti pengelolaan pengguna, penagihan, dan integrasi yang terpusat.

close


Pilih organisasi tujuan
1 baris 

more_vert



Organisasi



ID
cyberfighter.org
C
cyberfighter.org lbmtrFy4Q6ektP2sK44fDw
info_outline



