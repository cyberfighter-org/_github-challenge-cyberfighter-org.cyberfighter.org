Domain : cyberfighter.org
=========================
Admin: (1) eysz7x@mailbox.org 
=============================
(2) cyberfighter.org@gmail.com
=========================
Organization: cyberfighter.org
==============================



<h1>Verify domain</h1>

Before we can verify <b><a href="https://github.com/orgs/cyberfighter-org/domain/MDE4Ok9yZ2FuaXphdGlvbkRvbWFpbjM4NzY4/verification_steps"><span style= "color:#4d4d4d;"> cyberfighter.org</span></a></b>, you'll need to complete these verification steps:

<h2>Add a DNS TXT record</h2>
1. Create a TXT record in your DNS configuration for
<code> _github-challenge-cyberfighter-org.cyberfighter.org.
</code>

2. Use this code as the value for the TXT record:

| TXT record |
|:-|:-|
| 141277c05   |


<b><span style= "color:#141277;">Note: this code will expire in 7 days.</span></b>

Wait until your DNS configuration changes. This could take up to 72 hours.








|Expected vs actual record |Priority	|Host name	|Points to address or value	|TTL	|Status|
|:--|:--|:--|:--|:--|:--|:--|
|Expected record	|32767	|@	|ms53321385.msv1.invalid.	|3600	|Not yet added correctly
|Actual record	|   |   |   |			        |Missing record

* * *

# New domain

All domains to be used in bmbo require a security key to be added in the domain management. If you did so already, then you can proceed with adding the domain.
Domain name autorenew

Please add the following entry in the domain management:
0aaec26db001cd44249c4b49bdf6a7270919e009.cyberfighter.org
c430facbf3666031ac8a14364375c7642aa8c323

This will check if your security key has been added properly in the domain management. If the check is successful, then you can proceed to adding the domain.
